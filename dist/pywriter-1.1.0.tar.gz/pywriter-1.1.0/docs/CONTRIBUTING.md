# Contributing

You can contribute to this project by either one of these methods:

- Creating an issue, so we fix or make corrections to make this project more exciting.
- Fork the repo and make a pull request.
- Or you can just email me via [engineeramarquaye@gmail.com](mailto:engineeramarquaye@gmail.com)
