from .__main__ import write, writer, typewriter 
     
__all__ = ['write', 'writer', 'typewriter']
