from .__main__ import write, reverse, typewriter

__all__ = ["write", "reverse", "typewriter"]
